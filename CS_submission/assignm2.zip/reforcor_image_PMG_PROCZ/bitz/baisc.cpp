//
informz


image objects set for proper stripe out all freinz
finsh obj factory
and image process production
create masks and apply_intensity_scaler
 _+X and wtire! fix file reading
 
