









auto histagram_RGB_raw_touple = std::make_tuple(int[256],int[256],int[256]);



std::tuple<int[256],int[256],int[256]> hista_raw_RGB_tuple_constct(*)
{
      int red[256],green[256],blue[256];


        for(int i = 0; i<256; i++)

      return std::make_tuple(red,green,blue);
      }

for(int i = 0; i<256; i++)
{

  std::tie(red,green,blue)=histagram_RGB_raw_touple ;

histagram_RGB_raw_touple
unsigned char raw_hista_rgb_colour[]
}

std::size_t size() const noexcept { return storage_and_mutex_.first().size(); }

void reset() { storage_and_mutex_.first().reset(size()); }
