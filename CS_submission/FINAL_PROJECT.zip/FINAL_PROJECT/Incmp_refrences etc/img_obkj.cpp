//class img_obkj.cpp


#include "img_obkj.h"
